import React,{Component} from 'react'
export default class Test extends Component{

    render(){
        return (<p>Salam React</p>)
    }
}